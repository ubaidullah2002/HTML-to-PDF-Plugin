jQuery(document).ready(function () {
    jQuery('#generate-pdf-btn').on('click', function (e) {
        e.preventDefault();
        var url = jQuery('#pdf-url-input').val();
        if (!url) {
            alert('Please enter a URL.');
            return;
        }
        jQuery('#pdf-loader').show();
        jQuery.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'generate_pdf',
                url: url,
            },
            success: function (response) {
                jQuery('#pdf-loader').hide();
                if (response.success) {
                    alert('PDF generated successfully! Download it here: ' + response.data.pdf_url);
                } else {
                    alert(response.data.message || 'Failed to generate PDF.');
                }
            },
            error: function () {
                jQuery('#pdf-loader').hide();
                alert('An error occurred.');
            },
        });
    });
});
