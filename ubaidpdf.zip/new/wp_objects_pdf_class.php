<?php
class WP_Objects_PDF_Class {
    public function generate_pdf_from_url($url) {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return "Invalid URL";
        }
        require_once 'path/to/dompdf/autoload.inc.php';
        $dompdf = new Dompdf\Dompdf();
        $html = file_get_contents($url);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $pdf_path = plugin_dir_path(__FILE__) . 'generated_pdfs/url_pdf_' . time() . '.pdf';
        file_put_contents($pdf_path, $dompdf->output());
        return $pdf_path;
    }
}
?>
