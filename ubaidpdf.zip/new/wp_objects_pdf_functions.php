<?php
add_action('wp_ajax_generate_pdf_from_url', 'wppg_generate_pdf_from_url');

function wppg_generate_pdf_from_url() {
    $url = $_POST['url'] ?? '';
    if (empty($url)) {
        wp_send_json_error(['message' => 'URL is required.']);
    }

    $pdf_class = new WP_Objects_PDF_Class();
    $pdf_path = $pdf_class->generate_pdf_from_url($url);

    if (file_exists($pdf_path)) {
        wp_send_json_success(['message' => 'PDF generated successfully.', 'pdf_path' => $pdf_path]);
    } else {
        wp_send_json_error(['message' => 'Failed to generate PDF.']);
    }
}
?>
