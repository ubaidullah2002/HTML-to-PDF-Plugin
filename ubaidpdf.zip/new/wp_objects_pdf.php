<?php
/**
 * Plugin Name: Ubaid PDF
 * Plugin URI: https://example.com/ubaid-pdf-generator
 * Description: A WordPress plugin to generate PDFs from URLs.
 * Version: 1.0.0
 * Author: Tayyab Sajjad
 * Author URI: https://github.com/devtayyabsajjad
 * License: GPL2
 */

// Register the shortcode
function ubaid_pdf_generator_shortcode() {
    ob_start(); // Start output buffering to capture HTML
    ?>
    <div id="ubaid-pdf-generator" style="margin-top: 20px;">
        <label for="ubaid-pdf-url-input">Enter URL:</label>
        <input type="text" id="ubaid-pdf-url-input" name="ubaid-pdf-url-input" placeholder="Paste URL here" style="width: 80%; margin-bottom: 10px;" />
        <button id="ubaid-generate-pdf-btn" class="button button-primary">Generate PDF</button>
    </div>
    <div id="ubaid-pdf-loader" style="display: none; margin-top: 10px;">
        <img src="<?php echo plugins_url('assets/loading.gif', __FILE__); ?>" alt="Loading..." />
        <p>Generating PDF, please wait...</p>
    </div>
    <script src="<?php echo plugins_url('assets/script.js', __FILE__); ?>"></script>
    <?php
    return ob_get_clean(); // Return the captured HTML
}
add_shortcode('ubaid_pdf_generator', 'ubaid_pdf_generator_shortcode');

// Handle AJAX request for PDF generation
function ubaid_generate_pdf_ajax() {
    $url = isset($_POST['url']) ? sanitize_text_field($_POST['url']) : '';
    if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        wp_send_json_error(['message' => 'Invalid URL provided.']);
        return;
    }

    // Generate PDF using a custom function (defined in ubaid_pdf_class.php)
    require_once plugin_dir_path(__FILE__) . 'ubaid_pdf_class.php';
    $pdf_class = new Ubaid_PDF_Class();
    $pdf_path = $pdf_class->generate_pdf_from_url($url);

    if ($pdf_path) {
        wp_send_json_success(['message' => 'PDF generated successfully!', 'pdf_url' => plugins_url('generated_pdfs/' . basename($pdf_path), __FILE__)]);
    } else {
        wp_send_json_error(['message' => 'Failed to generate PDF.']);
    }
}
add_action('wp_ajax_generate_pdf', 'ubaid_generate_pdf_ajax');
add_action('wp_ajax_nopriv_generate_pdf', 'ubaid_generate_pdf_ajax');
?>
